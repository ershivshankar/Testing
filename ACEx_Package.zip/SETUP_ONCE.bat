@echo off
title ACEx Lite - One-Time Setup
cd /d "%~dp0"

:: ── Elevation Check ─────────────────────────────────────────────────────────
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo.
    echo  ===================================================================
    echo   [!] Administrator rights are required to configure hosts and certs.
    echo       Requesting elevation...
    echo  ===================================================================
    echo.
    powershell -Command "Start-Process cmd -ArgumentList '/c \"\"%~f0\"\" %*' -Verb RunAs"
    exit /b
)

cls
echo =======================================================================
echo                     ACEX LITE - ONE-TIME SETUP
echo =======================================================================
echo.

:: ── 1. Check Python ─────────────────────────────────────────────────────────
echo [1/5] Checking Python installation...
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo.
    echo   [!] WARNING: Python is not detected in your PATH.
    echo       Please install Python 3.10+ from https://www.python.org/downloads/
    echo       (Make sure to check "Add Python to PATH" during installation).
    echo.
) else (
    echo   [OK] Python is installed.
)

:: ── 2. Add Hosts Entry ──────────────────────────────────────────────────────
echo [2/5] Configuring hosts file redirect...
set HOSTS=%WINDIR%\System32\drivers\etc\hosts
findstr /i "xmmrxzlcsfwojcpwkngs.supabase.co" "%HOSTS%" >nul 2>&1
if %errorlevel% neq 0 (
    echo 127.0.0.1 xmmrxzlcsfwojcpwkngs.supabase.co>> "%HOSTS%"
    echo   [OK] Added redirect to hosts file.
) else (
    echo   [OK] Hosts file redirect already present.
)

:: ── 3. Install SSL Certificate into Trusted Root ────────────────────────────
echo [3/5] Installing local SSL certificate...
if exist "%~dp0ca_cert.der" (
    certutil -addstore -f "Root" "%~dp0ca_cert.der" >nul 2>&1
    echo   [OK] Root SSL certificate installed into Windows Trusted Root store.
) else (
    echo   [!] Warning: ca_cert.der not found in current folder.
)

:: ── 4. Setup APPDATA Proxy Files ────────────────────────────────────────────
echo [4/5] Copying background proxy files to AppData...
set APPDATA_DIR=%APPDATA%\ACExLite
if not exist "%APPDATA_DIR%" mkdir "%APPDATA_DIR%" >nul 2>&1

if exist "%~dp0acex_proxy.py" copy /y "%~dp0acex_proxy.py" "%APPDATA_DIR%\" >nul 2>&1
if exist "%~dp0fake_supabase_cert.pem" copy /y "%~dp0fake_supabase_cert.pem" "%APPDATA_DIR%\" >nul 2>&1
if exist "%~dp0fake_supabase_key.pem" copy /y "%~dp0fake_supabase_key.pem" "%APPDATA_DIR%\" >nul 2>&1
if exist "%~dp0WebView2Loader.dll" copy /y "%~dp0WebView2Loader.dll" "%APPDATA_DIR%\" >nul 2>&1
echo   [OK] Proxy files deployed to %APPDATA_DIR%.

:: ── 5. Register Zero-UAC Scheduled Task ─────────────────────────────────────
echo [5/5] Registering zero-UAC elevated task...
powershell -NoProfile -Command ^
  "$taskName = 'ACExLiteLauncher'; ^
   $action = New-ScheduledTaskAction -Execute 'cmd.exe' -Argument '/c \"\"%~dp0launch_core.bat\"\"' -WorkingDirectory '%~dp0'; ^
   $principal = New-ScheduledTaskPrincipal -UserId ([System.Security.Principal.WindowsIdentity]::GetCurrent().Name) -LogonType Interactive -RunLevel Highest; ^
   $settings = New-ScheduledTaskSettingsSet -ExecutionTimeLimit (New-TimeSpan -Hours 24) -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries; ^
   Unregister-ScheduledTask -TaskName $taskName -Confirm:$false -ErrorAction SilentlyContinue; ^
   Register-ScheduledTask -TaskName $taskName -Action $action -Principal $principal -Settings $settings -Force | Out-Null"
echo   [OK] Scheduled task 'ACExLiteLauncher' registered.

cls
echo =======================================================================
echo                     SETUP COMPLETED SUCCESSFULLY!
echo =======================================================================
echo.
echo   You are now ready to run ACEx Lite.
echo.
echo   TO LAUNCH:
echo     Simply double-click:  launch_acex.bat
echo.
echo   - No UAC prompts will appear.
echo   - Alt + / will toggle the window anywhere.
echo   - Log in with your credentials (shiv / 1234@Shiv).
echo.
echo =======================================================================
echo.
if "%1"=="/auto" goto :done
pause
:done
