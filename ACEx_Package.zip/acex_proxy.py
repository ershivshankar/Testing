"""
ACEx Lite local HTTPS proxy — sits between the binary and Supabase.
- Listens on 127.0.0.1:443 with self-signed cert (already in Trusted Root)
- Receives login POST from acex-lite-final.exe
- Validates credentials against YOUR Supabase (vlxyubrjrpnldbiwijci)
- Returns proper JSON for all endpoints: version-check, session-check, realtime-token, user-tier, apikeys
"""

import ssl, json, hashlib, http.server, urllib.request, urllib.error, datetime, time, uuid, os

SUPABASE_URL  = "https://vlxyubrjrpnldbiwijci.supabase.co"
SUPABASE_KEY  = "sb_publishable_iXwfs9OoU0JCXwknze_0tQ_6SeDNGve"
BASE_DIR      = os.path.dirname(os.path.abspath(__file__))
CERT_FILE     = os.path.join(BASE_DIR, "fake_supabase_cert.pem")
KEY_FILE      = os.path.join(BASE_DIR, "fake_supabase_key.pem")
LOG_FILE      = os.path.join(BASE_DIR, "proxy_traffic.log")

def log(msg):
    ts = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{ts}] {msg}"
    print(line, flush=True)
    try:
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except:
        pass

def supabase_get(table, filters):
    """Query Supabase REST API."""
    params = "&".join(f"{k}=eq.{v}" for k, v in filters.items())
    url = f"{SUPABASE_URL}/rest/v1/{table}?{params}&select=*"
    req = urllib.request.Request(url, headers={
        "apikey": SUPABASE_KEY,
        "Authorization": f"Bearer {SUPABASE_KEY}",
        "Content-Type": "application/json"
    })
    try:
        r = urllib.request.urlopen(req, timeout=8)
        return json.loads(r.read())
    except Exception as e:
        log(f"Supabase query failed: {e}")
        return []

class ProxyHandler(http.server.BaseHTTPRequestHandler):

    def do_POST(self):
        length = int(self.headers.get("Content-Length", 0))
        body_raw = self.rfile.read(length) if length else b"{}"
        log(f"Incoming POST {self.path} (Length: {length})")

        try:
            body = json.loads(body_raw)
        except:
            body = {}

        path = self.path.split("?")[0]

        # 0. Storage / Files (WebView2Loader.dll)
        if "WebView2Loader" in path:
            dll_path = os.path.join(BASE_DIR, "WebView2Loader.dll")
            if not os.path.exists(dll_path):
                dll_path = r"F:\safe\WebView2Loader.dll"
            if os.path.exists(dll_path):
                with open(dll_path, "rb") as f:
                    data = f.read()
                self.send_response(200)
                self.send_header("Content-Type", "application/octet-stream")
                self.send_header("Content-Length", str(len(data)))
                self.end_headers()
                self.wfile.write(data)
                log(f"Served WebView2Loader.dll ({len(data)} bytes) -> 200 OK")
                return

        # 1. Version Check
        if "version-check" in path:
            resp = {
                "current": "1.1.5",
                "minimum": "1.0.0",
                "app_version": {"current": "1.1.5", "minimum": "1.0.0"},
                "update_required": False,
                "download_url": "",
                "status": "ok"
            }
            log(f"Handled version check -> 200 OK")
            self._send_json(resp, 200)
            return

        # 2. Session Check
        if "session-check" in path:
            resp = {
                "valid": True,
                "status": "active",
                "device_check": {"allowed": True, "status": "ok"},
                "message": "Session valid"
            }
            log(f"Handled session check -> 200 OK")
            self._send_json(resp, 200)
            return

        # 3. Mint Realtime Token
        if "mint-realtime-token" in path:
            fake_token = "rt_" + str(uuid.uuid4()).replace("-", "")
            resp = {
                "token": fake_token,
                "realtime_token": fake_token,
                "status": "success",
                "expires_at": int(time.time()) + 86400
            }
            log(f"Handled mint realtime token -> 200 OK")
            self._send_json(resp, 200)
            return

        # 4. User Tier
        if "get-user-tier" in path:
            resp = {
                "tier": "pro",
                "tier_name": "Pro Tier",
                "status": "active",
                "features": ["all", "desktop_jump", "seb_bypass"],
                "device_check": {"allowed": True, "status": "ok"}
            }
            log(f"Handled get user tier -> 200 OK")
            self._send_json(resp, 200)
            return

        # 5. Login / API Keys authentication
        username = body.get("username", "")
        password = body.get("password", "")
        log(f"Login attempt received: username='{username}' on path='{path}'")

        if not username or not password:
            log(f"Empty credentials provided on {path}")
            self._send_json({"error": "Username and password required", "code": 400}, 400)
            return

        # Validate against Supabase
        pwd_hash = hashlib.sha256(password.encode()).hexdigest()
        rows = supabase_get("acex_users", {"username": username})

        user = None
        for row in rows:
            if row.get("password") == password or row.get("password") == pwd_hash:
                user = row
                break

        if not user:
            log(f"AUTH FAILED for username='{username}' (invalid credentials)")
            resp = {"error": "Invalid username or password.", "code": 401}
            self._send_json(resp, 401)
            return

        if not user.get("is_active", True):
            log(f"AUTH BLOCKED for username='{username}' (account disabled)")
            resp = {"error": "Account disabled.", "code": 403}
            self._send_json(resp, 403)
            return

        # Generate successful session tokens
        session_token = str(uuid.uuid4()).replace("-", "") + str(uuid.uuid4()).replace("-", "")
        refresh_token = str(uuid.uuid4()).replace("-", "") + str(uuid.uuid4()).replace("-", "")
        expires_at    = int(time.time()) + 30 * 24 * 3600

        resp = {
            "session_token":  session_token,
            "refresh_token":  refresh_token,
            "expires_at":     expires_at,
            "api_keys":       {"apikey": user.get("apikey", "acex_key_shiv_full")},
            "device_check":   {"allowed": True, "status": "ok"},
            "app_version":    {"current": "1.1.5", "minimum": "1.0.0"},
            "tier":           "pro",
            "status":         "success"
        }
        log(f"AUTH SUCCESS for username='{username}' -> Granted LoggedIn session")
        self._send_json(resp, 200)

    def do_GET(self):
        self.do_POST()

    def _send_json(self, obj, code=200):
        data = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def log_message(self, fmt, *args):
        pass

class ThreadingHTTPServer(http.server.ThreadingHTTPServer):
    def handle_error(self, request, client_address):
        pass

if __name__ == "__main__":
    while True:
        try:
            server = ThreadingHTTPServer(("127.0.0.1", 443), ProxyHandler)
            ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
            ctx.load_cert_chain(CERT_FILE, KEY_FILE)
            server.socket = ctx.wrap_socket(server.socket, server_side=True)
            log(f"HTTPS proxy listening on 127.0.0.1:443 (Backend: {SUPABASE_URL})")
            server.serve_forever()
        except Exception as e:
            log(f"Server loop error: {e}, restarting in 1s...")
            time.sleep(1)
