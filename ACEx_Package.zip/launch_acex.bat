@echo off
title ACEx Lite Launcher
cd /d "%~dp0"

:: Check if already elevated
net session >nul 2>&1
if %errorlevel% == 0 (
    call "%~dp0launch_core.bat"
    goto :done
)

:: Fire elevated task: zero UAC prompt, full administrator privileges
schtasks /run /tn "ACExLiteLauncher" >nul 2>&1
if %errorlevel% neq 0 (
    call "%~dp0launch_core.bat"
)

:done
cls
echo =======================================================================
echo                         ACEX LITE LAUNCHER
echo =======================================================================
echo.
echo   1. The ACEx Lite window is open in standard small size.
echo   2. Log in (shiv / 1234@Shiv).
echo   3. Launch your assessment file:
echo        FACEPrep_Assessments.seb
echo.
echo   4. Alt + / now toggles ACEx Lite overlay everywhere.
echo =======================================================================
echo.
ping 127.0.0.1 -n 4 >nul
exit
