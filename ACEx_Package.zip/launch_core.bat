@echo off
title ACEx Lite [ADMIN]
cd /d "%~dp0"

echo [1/4] Cleaning background processes...
taskkill /f /im SafeExamBrowser.exe >nul 2>&1
taskkill /f /im SafeExamBrowser.Client.exe >nul 2>&1
taskkill /f /im CefSharp.BrowserSubprocess.exe >nul 2>&1
taskkill /f /im acex-lite.exe >nul 2>&1
taskkill /f /im acex-lite-final.exe >nul 2>&1
taskkill /f /im RuntimeHost.exe >nul 2>&1

echo [2/4] Resetting window dimensions to standard small size (600x576)...
python -c "import json, os; p=os.path.join(os.environ.get('APPDATA'), 'ACExLite', 'hotkeys.json'); (lambda: (d:=json.load(open(p)), d.update({'window':{'width':600,'height':576,'x':264,'y':104}}), open(p,'w').write(json.dumps(d,indent=4))) if os.path.exists(p) else None)()" >nul 2>&1

echo [3/4] Ensuring authentication proxy is active on port 443...
powershell -NoProfile -Command "if (-not (Get-NetTCPConnection -LocalPort 443 -ErrorAction SilentlyContinue)) { Start-Process python -ArgumentList '\"%APPDATA%\ACExLite\acex_proxy.py\"' -WindowStyle Hidden }"

echo [4/4] Starting ACEx Lite with full privileges...
start "" "%~dp0acex-lite-final.exe"
